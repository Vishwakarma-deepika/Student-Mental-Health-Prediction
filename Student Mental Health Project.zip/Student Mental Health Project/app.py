from flask import Flask, redirect, url_for, render_template, request
from flask_sqlalchemy import SQLAlchemy
import joblib

app=Flask(__name__)


#databse configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/users'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

scaler=joblib.load('scaler_model.pkl')
mlmodel=joblib.load('ml_model.pkl')

@app.route("/ml")
def ml():
    res=render_template("ml.html")
    return res

@app.route("/result", methods=['GET', 'POST'])
def result():
    lis = []

    # Convert all inputs to int/float (jo bhi appropriate ho)
    lis.append(int(request.form['Gender']))
    lis.append(int(request.form['Education Level']))
    lis.append(int(request.form['Feeling down, depressed, or hopeless']))
    lis.append(int(request.form['Little interest or pleasure in doing thing']))
    lis.append(int(request.form['Are you having proper sleep or not minimum 6hrs daily']))
    lis.append(int(request.form['Feeling tired or having little energy']))
    lis.append(int(request.form['Taking Proper Meal or Not']))
    lis.append(int(request.form['Feeling bad about yourself or that you are a failure or not have let yourself or your family down']))
    lis.append(int(request.form['Did you feel trouble on concentrating on things, such as reading the newspaper or studying or reading books or while watching television and etc...']))
    lis.append(int(request.form['Moving or speaking so slowly that other people could have noticed Or being so restless that you have been moving around a lot more than']))
    lis.append(int(request.form['Thoughts that you would be better off dead or of hurting yourself in some way']))
    lis.append(int(request.form['Did you live with your family or not']))
    lis.append(int(request.form['Do you have part-time or full-time job']))

    # numeric inputs (hours, percentage etc.)
    lis.append(float(request.form['How many hours do you spend studying each day(Self Studying)?']))
    lis.append(float(request.form['How many hour do you spend electronic gadgets (e.g. mobile phone, computer, laptop, PSP, PS4.0, Wii, etc.)']))
    lis.append(float(request.form['How many hours do you spend on social media per day?']))
    lis.append(float(request.form['How many hours of physical activity or exercise do you engage in weekly?']))
    lis.append(int(request.form['Do you consume substances such as alcohol, tobacco, or drugs?']))
    lis.append(float(request.form['Your Last Year Percentage']))

    # Scaling input
    scaled_input = scaler.transform([lis])

    # Prediction
    ans = mlmodel.predict(scaled_input)[0]

    # Render result page
    return render_template("result.html", ans=ans, lis=lis)






class student(db.Model):
    name=db.Column(db.String(80), nullable=False)
    username=db.Column(db.String(80), primary_key=True)
    password=db.Column(db.String(10), nullable=False)

with app.app_context():
    db.create_all()

@app.route("/")
def stud():
    return render_template("welcome.html")

@app.route("/register",methods=['GET','POST'])
def register():
    if request.method=="POST":
        name=request.form['name']
        username=request.form['username']
        password=request.form['Password']
        entry=student(name=name,username=username,password=password)
        db.session.add(entry)
        db.session.commit()
        return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username == "admin" and password == "123":
            return redirect(url_for("home"))
        else:
            return "Invalid Credentials! Try again."
    return render_template("login.html")


@app.route("/home")
def home():
    return render_template("home.html")



if __name__=="__main__":
    app.run(debug=True)